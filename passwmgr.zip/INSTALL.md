# Installation — Password-MGR v2.1
## Fedora 42 +
sudo dnf install -y zip coreutils util-linux
## Ubuntu 24.04 +
sudo apt install -y zip coreutils util-linux
